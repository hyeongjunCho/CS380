#define _tmain main
#define _TCHAR char